package sample;

public class Notation {

    public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException{

        NotationQueue<Character> pq = new NotationQueue<Character>();
        NotationStack<Character> s = new NotationStack<Character>();



        for(int counter = 0; counter<infix.length(); ++counter){

            char x = infix.charAt(counter);

            if(x == ' '){
                continue;
            }
            else if (Character.isDigit(x)){
                pq.enqueue(x);
            }
            else if(x == '('){
                s.push(x);
            }
            else if(x == ')'){
                while(((char)s.top() != '(') && (!s.isEmpty())){
                    pq.enqueue((char)s.pop());
                }

                if(((char)s.top() != '(') && (!s.isEmpty())){
                    throw new InvalidNotationFormatException("InvalidNotationFormatException");
                }
                else{
                    s.pop();
                }
            }

            else if(isOp(x)){
                while(higher(x, (char) s.top()) && !s.isEmpty()){
                    if((char) s.top() == '('){
                        throw new InvalidNotationFormatException("InvalidNotationFormatException");
                    }
                    pq.enqueue((char)s.pop());
                }
                s.push(x);
            }


        }

        while(!s.isEmpty()){
            if((char)s.top() == '('){
                throw new InvalidNotationFormatException("InvalidNotationFormatException");
            }
            pq.enqueue((char)s.pop());
        }

        String toReturn = pq.toString();
        return toReturn;
    }


    public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException{

        NotationStack<Character> s = new NotationStack<Character>();
        char x;
        String toReturn = "";

        for (int counter = 0; counter < postfix.length(); ++counter){
            x = postfix.charAt(counter);


            if(x == ' '){
                continue;
            }
            else if(Character.isDigit(x)){
                s.push(x);
            }
            else if(isOp(x)){
                if(s.size() < 2){
                    throw new InvalidNotationFormatException("InvalidNotationFormat");
                }
                String s1 = String.valueOf(s.pop());
                String s2 = String.valueOf(s.pop());

                String topush = '(' + s2 + x + s1 + ')';
                s.push(topush);

            }
        }

        if (s.size() != 0){
            throw new InvalidNotationFormatException("InvalidNotationFormatException");
        }
        toReturn = s.toString();
        return toReturn;

    }


    public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException{
        double toReturn = 0.0;

        NotationStack<Double> s = new NotationStack<Double>();
        char x;

        for(int counter = 0; counter < postfixExpr.length(); ++counter){

            x = postfixExpr.charAt(counter);

            if(x == ' '){
                continue;
            }
            else if(Character.isDigit(x)){
                s.push(x);
            }
            else if(isOp(x)){

                if(s.size() < 2){
                    throw new InvalidNotationFormatException("InvalidNotationFormat");
                }
                double d1 = Double.parseDouble(String.valueOf(s.pop()));
                double d2 = Double.parseDouble(String.valueOf(s.pop()));

                if(x == '+'){
                    s.push(d1 + d2);
                } else if (x == '*'){
                    s.push(d1 * d2);
                } else if (x == '-'){
                    s.push(d2 - d1);
                } else if(x == '/'){
                    s.push(d2 / d1);
                }

            }

        }


        toReturn = (double) s.pop();
        return toReturn;

    }

    private static boolean isOp(char x){
        boolean toReturn = false;
        if(x == '+' || x == '-'  || x == '*' || x == '/'){
            toReturn =  true;
        }
        return toReturn;
    }

    static boolean higher(char x, char y){
        if ((x == '+' || x == '-') && (y == '*' || y == '/')){
            return true;
        }
        else if((x == '+' || x == '-') && (y == '+' || y == '-')){
            return true;
        }
        else if((x == '*' || x == '-') && (y == '*' || y == '/')){
            return true;
        }
        else{
            return false;
        }
    }

public static double evaluateInfixExpression(String infixExpr) throws InvalidNotationFormatException{

        double toReturn = 0.0;
        String postfixExpr = convertInfixToPostfix(infixExpr);
        toReturn = evaluatePostfixExpression(postfixExpr);
        return toReturn;

    }





}
