package sample;

public class StackUnderflowException extends InvalidNotationFormatException{

    public StackUnderflowException(String toDisplay){

        super(toDisplay);

    }

}
