package sample;

public class StackOverflowException extends InvalidNotationFormatException{

    public StackOverflowException(String toDisplay){

        super(toDisplay);

    }

}
