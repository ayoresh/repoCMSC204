package sample;

public class QueueUnderflowException extends Exception{

    public QueueUnderflowException(String toDisplay){

        super(toDisplay);

    }
}
