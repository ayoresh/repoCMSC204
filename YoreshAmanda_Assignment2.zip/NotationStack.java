package sample;
import java.util.ArrayList;


public class NotationStack<T> implements  StackInterface {


    int maxSize = 100;
    ArrayList<T> aList;
    public NotationStack(){
        this(100);
    }
    public NotationStack(int x){
        this.maxSize = x;
        aList = new ArrayList<T>(x);
    }
    public NotationStack(ArrayList<T> sent){
        this.aList = sent;
    }

    @Override
    public boolean isEmpty() {
        boolean toReturn = false;
        if(aList.size() == 0){
            toReturn = true;
        }
        return toReturn;
    }

    @Override
    public boolean isFull() {
        boolean toReturn = false;
        if(aList.size() == maxSize){
            toReturn = true;
        }
        return toReturn;
    }

    @Override
    public Object pop() throws StackUnderflowException {
        if(this.isEmpty()){
            throw new StackUnderflowException("StackUnderflowException");
        }
        T end = aList.get(aList.size() - 1);
        aList.remove(aList.size() - 1);
        return end;
    }

    @Override
    public Object top() throws StackUnderflowException {
        if(this.isEmpty()){
            throw new StackUnderflowException("StackUnderflowException");
        }

        return aList.get(aList.size() - 1);
    }

    @Override
    public int size() {
        return aList.size();
    }

    @Override
    public boolean push(Object e) throws StackOverflowException {
        if(this.isFull()){
            throw new StackOverflowException("StackOverflowException");
        }
        aList.add((T) e);
        return true;
    }

    @Override
    public String toString(String delimiter) {
        String toReturn = "";

        for(T elemnt:aList){
            if(aList.indexOf(elemnt) == aList.size() - 1){
                toReturn += elemnt;
            }
            else{
                toReturn += elemnt + delimiter;
            }
        }
        return toReturn;
    }

    //Needed to not make NotationStack abstract
    @Override
    public void fill(ArrayList list) {

    }

    public String toString(){
        String toReturn = "";
        for(T element:aList){
            toReturn += element;
        }
        return toReturn;
    }
}
