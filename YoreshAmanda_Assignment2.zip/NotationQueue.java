package sample;

import java.util.ArrayList;

public class NotationQueue<T> implements  QueueInterface {

    int maxSize = 100;
    ArrayList<T>  aList;

    //Constructors
    public NotationQueue(){
        this(100);
    }
    public NotationQueue(int size){
        this.maxSize = size;
        aList = new ArrayList<T>(size);
    }


    public NotationQueue(ArrayList<T> sent){
        this.aList = (ArrayList<T>) sent;
    }

    @Override
    public boolean isEmpty(){
        boolean toReturn = false;
        if(aList.size() == 0){
            toReturn = true;
        }
        return toReturn;
    }

    @Override
    public boolean isFull() {
        boolean toReturn = false;
        if(aList.size() == maxSize){
            toReturn = true;
        }
        return toReturn;
    }

    @Override
    public Object dequeue() throws QueueUnderflowException {

        if(isEmpty()){
            throw new QueueUnderflowException("QueueUnderflowException");
        }
        T end = aList.get(0);
        aList.remove(0);
        return end;
    }

    public int size(){
        return aList.size();
    }

    @Override
    public boolean enqueue(Object e) throws QueueOverflowException {
        if (isFull()){
            throw new QueueOverflowException("QueueOverflowException");
        }

        aList.add((T) e);
        return true;
    }

    @Override
    public String toString(String delimiter) {
        String toReturn = "";

        for(T elements:aList){
            if(aList.indexOf(elements) == (aList.size() - 1)){
                toReturn += elements;
            }
            else{
                toReturn += (elements + delimiter);
            }
        }
        return toReturn;
    }


    //Needed to not make NotationQueue abstract
   /** @Override
    public void fill(ArrayList list) {

    } */

    public String toString(){
        String toReturn = "";
        for(T elements:aList){
            toReturn += elements;
        }
        return toReturn;
    }
}
