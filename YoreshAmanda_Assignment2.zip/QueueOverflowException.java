package sample;

public class QueueOverflowException extends InvalidNotationFormatException{

    public QueueOverflowException(String toDisplay){

        super(toDisplay);

    }

}
