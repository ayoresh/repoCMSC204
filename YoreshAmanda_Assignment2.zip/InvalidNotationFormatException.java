package sample;

public class InvalidNotationFormatException extends Exception{

    public InvalidNotationFormatException(String toDisplay){
        super(toDisplay);
    }

}
